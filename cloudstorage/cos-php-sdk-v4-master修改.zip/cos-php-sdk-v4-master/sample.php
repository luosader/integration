<?php
// header('Content-Type:text/html;charset=UTF-8');//�����ַ���,��PHP��ʹ��
// ini_set('max_execution_time', '300');
// ini_set('memory_limit', '1024M');
// post_max_size��upload_max_filesize�޷���ini_set���ã�����.htaccess������

/*
 * ��Ѷ�� COS_v4
*/

require('./include.php');
use qcloudcos\Cosapi;// ����������֮ǰ���κ����
use qcloudcos\Conf;
// $bucket = 'test';// Bucket����
// $src = './1.jpg';// Ҫ�ϴ����ļ�
// $dst = '/666/1.jpg';// �ϴ��ļ�����λ��
// // $folder = '/ok';// �����ļ��У���$dst�޹�
Cosapi::setTimeout(180);
Cosapi::setRegion('gz'); // Set region to guangzou.


$form = <<<FORM
	<form action='' method='POST' enctype='multipart/form-data' >
	<input type='file' name='myfile' value='' />
	<input type='submit' name='submit' value='�ϴ��ļ�' />
	<form>
FORM;
echo $form;


$bucket = '';$src = '';$dst = '';$folder = '';
if (isset($_POST['submit'])) {
	$upfile = 'myfile';
    // if (@empty($_FILES[$upfile]['name'])) {
    //     echo "�ļ������ڣ�";
    // }

	$bucket = 'test';
	$src = $_FILES[$upfile]['tmp_name'];
	$folder = '/'.date('YmdHis',time());
	// $folder = '/tmp';
	$dst = $folder.'/'.$_FILES[$upfile]['name'];// �ϴ��ļ�����λ��
	// $dst = $folder.'/1.pdf';// �ϴ��ļ�����λ��
	$sliceSize = $_FILES[$upfile]['size'];

	echo "<pre>";
	// Create folder in bucket.
	$ret = Cosapi::createFolder($bucket, $folder);
	// var_dump($ret);

	// Upload file into bucket.
	$ret = Cosapi::upload($bucket, $src, $dst, null, $sliceSize);
	// $ret = Cosapi::upload($bucket, $src, $dst);
	// var_dump($ret);
	// echo $resource_path = str_replace('/'.(Conf::APP_ID).'/'.$bucket,'',$ret['data']['resource_path']);
	// mysql_query("INSERT INTO `op_photo` (resource_path) VALUES ('$resource_path');");
	// mysql_query("INSERT INTO `op_photo` (resource_path) VALUES ('$dst');");
	echo ($ret) ? '�ϴ��ɹ���' : '�ϴ�ʧ�ܣ�' ;

	// // List folder.
	// $ret = Cosapi::listFolder($bucket, $folder);
	// var_dump($ret);

	// // Update folder information.
	// $bizAttr = "";
	// $ret = Cosapi::updateFolder($bucket, $folder, $bizAttr);
	// var_dump($ret);

	// // Update file information.
	// $bizAttr = '';
	// $authority = 'eWPrivateRPublic';
	// $customerHeaders = array(
	//     'Cache-Control' => 'no',
	//     'Content-Type' => 'application/pdf',
	//     'Content-Language' => 'ch',
	// );
	// $ret = Cosapi::update($bucket, $dst, $bizAttr,$authority, $customerHeaders);
	// var_dump($ret);

	// // Stat folder.
	// $ret = Cosapi::statFolder($bucket, $folder);
	// var_dump($ret);

	// // Stat file.
	// $ret = Cosapi::stat($bucket, $dst);
	// var_dump($ret);

	// // Delete file.
	// $ret = Cosapi::delFile($bucket, $dst);
	// var_dump($ret);

	// Delete folder.
	// $ret = Cosapi::delFolder($bucket, $folder);
	// var_dump($ret);


	unset($_POST);

}


