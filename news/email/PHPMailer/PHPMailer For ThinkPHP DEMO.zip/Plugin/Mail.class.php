<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 15-11-9
 * Time: 下午12:05
 */
namespace Home\Plugin;
use Home\Plugin\PHPMail\PHPMailer;
class Mail extends PHPMailer{
    public static function Msend($config = array(),$send = array()){
        $mail = new self();
        $mail->SMTPAuth = true;
        $mail->setLanguage('zh_cn');

        $mail->Username = $config['username'];
        $mail->Password = $config['password'];
        $mail->Host = $config['mailhost'];
        $mail->Port = $config['port']?:465;
        if(!$config['secure'] == 'default'){
            $mail->SMTPSecure = $config['secure']?:'ssl';
        }

        $mail->Mailer = 'smtp';
        $mail->From = $config['username'];
        $mail->FromName = $config['fromname'];
        $mail->AddAddress($send['touser']);
        if($send['body'] != strip_tags($send['body'])){
            $mail->IsHTML(true);
        }else{
            $mail->IsHTML(false);
        }
        $mail->Subject = $send['title'];
        $mail->Body = $send['body'];

        if($mail->send()){
            return true;
        }else{
            C('senderror',$mail->ErrorInfo);
            return false;
        }
    }
}