﻿一、免责条款：

DEMO仅供参考，实际开发中需要结合具体业务场景修改使用。



二、Demo运行环境：

android手机版本SDK Version >= 16，如有需要请修改代码AndroidManifest的versionCode并重新打包运行