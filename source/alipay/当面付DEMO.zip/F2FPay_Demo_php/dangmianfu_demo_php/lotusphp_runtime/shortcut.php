<?php
function C($className)
{
	return LtObjectUtil::singleton($className);
}
